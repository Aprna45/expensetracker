// Personal Expense Tracker - Frontend logic (no framework, plain fetch + DOM)

const API = '/api/expenses';
let CATEGORIES = [];
let editingId = null;

const el = (id) => document.getElementById(id);

const form = el('expense-form');
const titleInput = el('title');
const amountInput = el('amount');
const categorySelect = el('category');
const dateInput = el('date');
const noteInput = el('note');
const formErrors = el('form-errors');
const formTitle = el('form-title');
const submitBtn = el('submit-btn');
const cancelEditBtn = el('cancel-edit-btn');

const filterTitle = el('filter-title');
const filterCategory = el('filter-category');
const filterFrom = el('filter-from');
const filterTo = el('filter-to');
const filterError = el('filter-error');
const clearFiltersBtn = el('clear-filters-btn');

const tbody = el('expense-tbody');
const listStatus = el('list-status');
const table = el('expense-table');

const summaryMonth = el('summary-month');
const summaryTotal = el('summary-total');
const summaryBreakdown = el('summary-breakdown');

const toast = el('toast');

function showToast(msg) {
  toast.textContent = msg;
  toast.hidden = false;
  clearTimeout(showToast._t);
  showToast._t = setTimeout(() => { toast.hidden = true; }, 2500);
}

function todayISO() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function currentMonthValue() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

function formatMoney(n) {
  return Number(n).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function escapeHtml(s) {
  const div = document.createElement('div');
  div.textContent = s;
  return div.innerHTML;
}

// ---------- Init ----------

async function loadCategories() {
  const res = await fetch('/api/categories');
  CATEGORIES = await res.json();

  categorySelect.innerHTML = CATEGORIES.map((c) => `<option value="${c}">${c}</option>`).join('');
  filterCategory.innerHTML =
    '<option value="">All</option>' + CATEGORIES.map((c) => `<option value="${c}">${c}</option>`).join('');
}

function init() {
  dateInput.value = todayISO();
  summaryMonth.value = currentMonthValue();
  loadCategories().then(() => {
    loadExpenses();
    loadSummary();
  });
}

// ---------- Form: add / edit ----------

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  formErrors.hidden = true;

  const payload = {
    title: titleInput.value,
    amount: amountInput.value === '' ? undefined : parseFloat(amountInput.value),
    category: categorySelect.value,
    date: dateInput.value || undefined,
    note: noteInput.value,
  };

  const isEdit = editingId !== null;
  const url = isEdit ? `${API}/${editingId}` : API;
  const method = isEdit ? 'PUT' : 'POST';

  try {
    const res = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();

    if (!res.ok) {
      renderFormErrors(data.errors || [data.error] || ['Something went wrong.']);
      return;
    }

    showToast(isEdit ? 'Expense updated.' : 'Expense added.');
    resetForm();
    loadExpenses();
    loadSummary();
  } catch (err) {
    renderFormErrors(['Could not reach the server. Is it running?']);
  }
});

function renderFormErrors(errors) {
  formErrors.innerHTML = '<ul>' + errors.map((e) => `<li>${escapeHtml(e)}</li>`).join('') + '</ul>';
  formErrors.hidden = false;
}

function resetForm() {
  editingId = null;
  form.reset();
  dateInput.value = todayISO();
  formTitle.textContent = 'Add Expense';
  submitBtn.textContent = 'Add Expense';
  cancelEditBtn.hidden = true;
  formErrors.hidden = true;
}

cancelEditBtn.addEventListener('click', resetForm);

function startEdit(expense) {
  editingId = expense.id;
  titleInput.value = expense.title;
  amountInput.value = expense.amount;
  categorySelect.value = expense.category;
  dateInput.value = expense.date;
  noteInput.value = expense.note || '';
  formTitle.textContent = `Edit Expense #${expense.id}`;
  submitBtn.textContent = 'Save Changes';
  cancelEditBtn.hidden = false;
  formErrors.hidden = true;
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ---------- List + filters ----------

function buildQuery() {
  const params = new URLSearchParams();
  if (filterTitle.value.trim()) params.set('title', filterTitle.value.trim());
  if (filterCategory.value) params.set('category', filterCategory.value);
  if (filterFrom.value) params.set('dateFrom', filterFrom.value);
  if (filterTo.value) params.set('dateTo', filterTo.value);
  return params.toString();
}

async function loadExpenses() {
  filterError.hidden = true;

  if (filterFrom.value && filterTo.value && filterFrom.value > filterTo.value) {
    filterError.textContent = '"From" date is after "To" date — no expenses can match this range.';
    filterError.hidden = false;
  }

  const query = buildQuery();
  const res = await fetch(`${API}${query ? '?' + query : ''}`);

  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    listStatus.textContent = data.error || 'Could not load expenses.';
    listStatus.hidden = false;
    table.style.display = 'none';
    return;
  }

  const expenses = await res.json();
  renderTable(expenses);
}

function renderTable(expenses) {
  if (expenses.length === 0) {
    table.style.display = 'none';
    listStatus.textContent = 'No expenses match. Add one above, or adjust your filters.';
    listStatus.hidden = false;
    return;
  }

  table.style.display = '';
  listStatus.hidden = true;

  tbody.innerHTML = expenses
    .map((e) => `
      <tr data-id="${e.id}">
        <td class="cell-date">${e.date}</td>
        <td>${escapeHtml(e.title)}</td>
        <td><span class="category-tag">${escapeHtml(e.category)}</span></td>
        <td class="cell-amount">$${formatMoney(e.amount)}</td>
        <td class="cell-note">${e.note ? escapeHtml(e.note) : '—'}</td>
        <td>
          <div class="row-actions">
            <button type="button" class="edit-btn">Edit</button>
            <button type="button" class="delete-btn">Delete</button>
          </div>
        </td>
      </tr>
    `)
    .join('');

  // Wire up row action buttons (stash the expense object on the row for editing).
  tbody.querySelectorAll('tr').forEach((row) => {
    const id = Number(row.dataset.id);
    const expense = expenses.find((e) => e.id === id);

    row.querySelector('.edit-btn').addEventListener('click', () => startEdit(expense));
    row.querySelector('.delete-btn').addEventListener('click', () => deleteExpense(id, expense.title));
  });
}

async function deleteExpense(id, title) {
  if (!confirm(`Delete "${title}"? This cannot be undone.`)) return;

  const res = await fetch(`${API}/${id}`, { method: 'DELETE' });
  if (!res.ok) {
    showToast('Could not delete expense.');
    return;
  }
  showToast('Expense deleted.');
  if (editingId === id) resetForm();
  loadExpenses();
  loadSummary();
}

[filterTitle, filterCategory, filterFrom, filterTo].forEach((input) => {
  input.addEventListener('input', loadExpenses);
  input.addEventListener('change', loadExpenses);
});

clearFiltersBtn.addEventListener('click', () => {
  filterTitle.value = '';
  filterCategory.value = '';
  filterFrom.value = '';
  filterTo.value = '';
  loadExpenses();
});

// ---------- Summary ----------

async function loadSummary() {
  const res = await fetch(`/api/summary?month=${summaryMonth.value}`);
  const data = await res.json();

  summaryTotal.textContent = `Total: $${formatMoney(data.total)}`;

  const entries = Object.entries(data.byCategory).filter(([, amt]) => amt > 0);
  if (entries.length === 0) {
    summaryBreakdown.innerHTML = '<li>No expenses this month yet.</li>';
    return;
  }

  entries.sort((a, b) => b[1] - a[1]);
  summaryBreakdown.innerHTML = entries
    .map(([cat, amt]) => `<li><span>${escapeHtml(cat)}</span><span class="amt">$${formatMoney(amt)}</span></li>`)
    .join('');
}

summaryMonth.addEventListener('change', loadSummary);

init();
