/**
 * Personal Expense Tracker - Backend
 * Node.js + Express, JSON file as the "database" (no external DB needed).
 */

const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'data', 'expenses.json');

const VALID_CATEGORIES = ['Food', 'Transport', 'Shopping', 'Bills', 'Entertainment', 'Other'];

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ---------- Storage helpers ----------

function ensureDataFile() {
  const dir = path.dirname(DATA_FILE);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, '[]', 'utf8');
}

function readExpenses() {
  ensureDataFile();
  try {
    const raw = fs.readFileSync(DATA_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    // Corrupt file - don't crash the app, just start fresh in memory.
    console.error('Failed to read/parse data file, treating as empty:', err.message);
    return [];
  }
}

function writeExpenses(expenses) {
  ensureDataFile();
  fs.writeFileSync(DATA_FILE, JSON.stringify(expenses, null, 2), 'utf8');
}

function nextId(expenses) {
  return expenses.reduce((max, e) => Math.max(max, e.id), 0) + 1;
}

// ---------- Validation ----------

function isValidDateString(s) {
  // Expect YYYY-MM-DD, and must represent a real calendar date.
  if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const [y, m, d] = s.split('-').map(Number);
  const date = new Date(y, m - 1, d);
  return date.getFullYear() === y && date.getMonth() === m - 1 && date.getDate() === d;
}

function todayString() {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

/**
 * Validates an incoming expense payload.
 * Returns { ok: true, value } or { ok: false, errors }
 */
function validateExpensePayload(body, { partial = false } = {}) {
  const errors = [];
  const value = {};

  // Title
  if (!partial || body.title !== undefined) {
    const title = typeof body.title === 'string' ? body.title.trim() : '';
    if (!title) errors.push('Title is required.');
    else if (title.length > 200) errors.push('Title must be 200 characters or fewer.');
    else value.title = title;
  }

  // Amount
  if (!partial || body.amount !== undefined) {
    const amount = typeof body.amount === 'string' ? parseFloat(body.amount) : body.amount;
    if (typeof amount !== 'number' || Number.isNaN(amount) || !Number.isFinite(amount)) {
      errors.push('Amount must be a number.');
    } else if (amount <= 0) {
      errors.push('Amount must be greater than 0.');
    } else if (amount > 100000000) {
      errors.push('Amount is unreasonably large.');
    } else {
      value.amount = Math.round(amount * 100) / 100; // round to cents
    }
  }

  // Category
  if (!partial || body.category !== undefined) {
    if (!VALID_CATEGORIES.includes(body.category)) {
      errors.push(`Category must be one of: ${VALID_CATEGORIES.join(', ')}.`);
    } else {
      value.category = body.category;
    }
  }

  // Date (defaults to today on create; on edit, only validate if provided)
  if (body.date !== undefined && body.date !== null && body.date !== '') {
    if (!isValidDateString(body.date)) {
      errors.push('Date must be a valid date in YYYY-MM-DD format.');
    } else {
      value.date = body.date;
    }
  } else if (!partial) {
    value.date = todayString();
  }

  // Note (optional)
  if (body.note !== undefined) {
    const note = typeof body.note === 'string' ? body.note.trim() : '';
    if (note.length > 2000) errors.push('Note must be 2000 characters or fewer.');
    else value.note = note;
  } else if (!partial) {
    value.note = '';
  }

  return errors.length ? { ok: false, errors } : { ok: true, value };
}

// ---------- Routes ----------

// GET /api/categories - list valid categories (lets frontend stay in sync with backend)
app.get('/api/categories', (req, res) => {
  res.json(VALID_CATEGORIES);
});

// GET /api/expenses - list, with optional filters: category, dateFrom, dateTo, title
app.get('/api/expenses', (req, res) => {
  let expenses = readExpenses();
  const { category, dateFrom, dateTo, title } = req.query;

  if (category) {
    expenses = expenses.filter((e) => e.category === category);
  }

  if (dateFrom) {
    if (!isValidDateString(dateFrom)) {
      return res.status(400).json({ error: 'dateFrom must be in YYYY-MM-DD format.' });
    }
    expenses = expenses.filter((e) => e.date >= dateFrom);
  }

  if (dateTo) {
    if (!isValidDateString(dateTo)) {
      return res.status(400).json({ error: 'dateTo must be in YYYY-MM-DD format.' });
    }
    expenses = expenses.filter((e) => e.date <= dateTo);
  }

  if (dateFrom && dateTo && dateFrom > dateTo) {
    // Weird range (from after to) - return empty result set rather than erroring,
    // since it's a valid (if pointless) query.
    expenses = [];
  }

  if (title) {
    const needle = title.toLowerCase();
    expenses = expenses.filter((e) => e.title.toLowerCase().includes(needle));
  }

  // Most recent first; tie-break by id desc so newest-entered wins on same date.
  expenses.sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : b.id - a.id));

  res.json(expenses);
});

// POST /api/expenses - create
app.post('/api/expenses', (req, res) => {
  const result = validateExpensePayload(req.body || {}, { partial: false });
  if (!result.ok) return res.status(400).json({ errors: result.errors });

  const expenses = readExpenses();
  const expense = { id: nextId(expenses), ...result.value };
  expenses.push(expense);
  writeExpenses(expenses);
  res.status(201).json(expense);
});

// PUT /api/expenses/:id - edit (partial update allowed)
app.put('/api/expenses/:id', (req, res) => {
  const id = Number(req.params.id);
  const expenses = readExpenses();
  const idx = expenses.findIndex((e) => e.id === id);
  if (idx === -1) return res.status(404).json({ error: 'Expense not found.' });

  const result = validateExpensePayload(req.body || {}, { partial: true });
  if (!result.ok) return res.status(400).json({ errors: result.errors });

  expenses[idx] = { ...expenses[idx], ...result.value };
  writeExpenses(expenses);
  res.json(expenses[idx]);
});

// DELETE /api/expenses/:id
app.delete('/api/expenses/:id', (req, res) => {
  const id = Number(req.params.id);
  const expenses = readExpenses();
  const idx = expenses.findIndex((e) => e.id === id);
  if (idx === -1) return res.status(404).json({ error: 'Expense not found.' });

  const [removed] = expenses.splice(idx, 1);
  writeExpenses(expenses);
  res.json(removed);
});

// GET /api/summary?month=YYYY-MM - defaults to current month
app.get('/api/summary', (req, res) => {
  let month = req.query.month;
  const now = new Date();
  const defaultMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;

  if (month && !/^\d{4}-\d{2}$/.test(month)) {
    return res.status(400).json({ error: 'month must be in YYYY-MM format.' });
  }
  month = month || defaultMonth;

  const expenses = readExpenses().filter((e) => e.date.startsWith(month));

  const byCategory = {};
  for (const cat of VALID_CATEGORIES) byCategory[cat] = 0;

  let total = 0;
  for (const e of expenses) {
    total += e.amount;
    byCategory[e.category] = (byCategory[e.category] || 0) + e.amount;
  }

  total = Math.round(total * 100) / 100;
  for (const cat of Object.keys(byCategory)) {
    byCategory[cat] = Math.round(byCategory[cat] * 100) / 100;
  }

  res.json({ month, total, byCategory, count: expenses.length });
});

app.listen(PORT, () => {
  console.log(`Expense tracker running at http://localhost:${PORT}`);
});
