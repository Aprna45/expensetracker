# Expense Tracker

A small personal expense tracker. Add expenses, view/filter them, edit or delete any of them, and see a monthly summary broken down by category.

## How to run it

Requirements: Node.js (v16+).

```bash
cd expense-tracker
npm install
npm start
```

Then open **http://localhost:3000** in a browser. That's it — no separate database to install or configure, no build step, no env vars.

To start fresh, stop the server and delete `data/expenses.json` (it'll be recreated empty on next start).

## Stack and why

- **Backend:** Node.js + Express. One file (`server.js`), no framework ceremony.
- **Storage:** a JSON file (`data/expenses.json`) read/written on every request. No real database, no native dependencies to compile, nothing to install beyond `npm install`. This is explicitly fine per the brief and is the fastest path to "actually works end-to-end" for a single-user, locally-run app. It will not scale to concurrent writers or large datasets, but that's not the goal here (see Tradeoffs).
- **Frontend:** plain HTML/CSS/JS, no framework, no build step or bundler. The UI is a single page that talks to the backend over a small REST API. This kept iteration fast and meant zero tooling friction to actually run the app.

## What it does

1. **Add an expense** — title, amount, category (one of Food / Transport / Shopping / Bills / Entertainment / Other), date (defaults to today if left blank), and an optional note.
2. **View all expenses** — sorted most-recent-date first, all fields visible in a table.
3. **Edit or delete** any expense, in place, from the table.
4. **Monthly summary** — total spent and a per-category breakdown for whichever month you select (defaults to the current month).
5. **Filter the list** — by category, by date range (from/to), and by title (partial, case-insensitive match). Filters combine (AND) and update the list live as you type/select.

## API

| Method | Route | Purpose |
|---|---|---|
| GET | `/api/expenses?category=&dateFrom=&dateTo=&title=` | List, filtered |
| POST | `/api/expenses` | Create |
| PUT | `/api/expenses/:id` | Update (partial — only send fields you're changing) |
| DELETE | `/api/expenses/:id` | Delete |
| GET | `/api/summary?month=YYYY-MM` | Total + category breakdown for a month (defaults to current month) |
| GET | `/api/categories` | The fixed list of valid categories |

All validation happens server-side (the frontend just relays whatever error messages come back), so the API is safe to hit directly/from a script and won't accept bad data just because the UI didn't catch it.

## Edge cases handled

- **Empty states:** no expenses at all, or a filter that matches nothing, both show a plain "nothing here" message instead of a blank table or a crash.
- **Invalid inputs:** missing title, non-numeric or zero/negative amount, category outside the fixed list, and a note over 2000 chars are all rejected server-side with a specific message per problem (not just "invalid").
- **Weird dates:** malformed strings and impossible calendar dates (e.g. `2026-02-30`, `2026-13-01`) are rejected rather than silently coerced by `new Date()`. The check actually re-derives the date and compares year/month/day, so JS's auto-rollover behavior (where `Feb 30` quietly becomes `Mar 2`) can't sneak bad data in.
- **Weird date ranges:** if `dateFrom` is after `dateTo` in a filter, the UI surfaces a note explaining why the result is empty, rather than just showing an empty list and leaving you to guess.
- **Partial edits:** editing an expense only sends/validates the fields that changed, so you can fix just the amount without re-validating or re-typing everything else.
- **Money rounding:** amounts are rounded to the cent on save, and summary totals are rounded again after summing, to avoid floating-point artifacts like `30.000000000004`.
- **Re-entrant deletes/edits:** deleting or editing an ID that no longer exists (e.g. two tabs open, or a double-click) returns a clean 404 rather than corrupting the data file.

## What's done vs. skipped, and why

**Done:** all 5 required features, full validation on every write path, the edge cases above, a responsive layout that doesn't fall apart at mobile widths.

**Skipped / simplified**, in order of what I'd tackle first if given more time:

- **Concurrency safety on the JSON file.** Every write does a full read-modify-write of the file with no locking. Fine for one person clicking around in a browser; would corrupt data under real concurrent writes. A real app would use SQLite (still zero-config, but transactional) — I'd swap this in first if this were going further than a local demo.
- **No pagination.** The list loads everything and filters client-side-via-API on every request. Fine for personal use (hundreds of expenses), would need pagination/indexing at real scale.
- **No multi-currency, no auth, no deployment config** — explicitly out of scope per the brief.
- **Category list is fixed in code** (both frontend and backend), not user-editable. Matches the brief ("one of: Food, Transport, Shopping, Bills, Entertainment, Other") but would need a small schema change to support custom categories.
- **No optimistic UI updates** — every add/edit/delete re-fetches the list and summary from the server rather than patching local state. Simpler and harder to get subtly wrong, at the cost of a tiny bit of extra latency per action (irrelevant on localhost).

## Known rough edges

- If two browser tabs are open and one deletes an expense the other is mid-edit on, the edit will fail with a 404 rather than gracefully merging — you'd just see the error and need to refresh.
- The date input relies on the browser's native `<input type="date">` picker; on browsers/OSes with unusual locale settings the picker's display format may differ from the `YYYY-MM-DD` the API expects, though the API itself always validates strictly regardless of what the picker sends.
- `data/expenses.json` is plain text with no backup/versioning — deleting it (or a bad manual edit) loses history. Acceptable for a local single-user tool, would not be for anything else.
